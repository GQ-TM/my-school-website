import React from 'react';
import { Bot, Sparkles } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="relative bg-gradient-to-br from-blue-900 via-blue-700 to-blue-500 text-white overflow-hidden">
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
      <div className="container mx-auto px-6 py-20 relative z-10 flex flex-col items-center text-center">
        <div className="bg-white/10 p-4 rounded-full mb-6 backdrop-blur-sm animate-bounce">
          <Bot size={48} className="text-blue-100" />
        </div>
        <h1 className="text-4xl md:text-6xl font-bold mb-4 leading-tight">
          الذكاء الاصطناعي في التعليم
        </h1>
        <p className="text-xl md:text-2xl text-blue-100 max-w-2xl mb-8 font-light">
          نحو مستقبل تعليمي أذكى وأكثر تفاعلية
        </p>
        <div className="flex items-center gap-2 bg-white/20 px-6 py-2 rounded-full backdrop-blur-sm">
          <Sparkles size={18} className="text-yellow-300" />
          <span className="text-sm md:text-base font-medium">مشروع مدرسي - مادة الحاسب وتقنية المعلومات</span>
        </div>
      </div>
      
      {/* Wave shape divider */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" className="fill-slate-50">
          <path fillOpacity="1" d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,112C672,96,768,96,864,112C960,128,1056,160,1152,160C1248,160,1344,128,1392,112L1440,96L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
        </svg>
      </div>
    </header>
  );
};

export default Header;