import React from 'react';
import { GraduationCap, Heart } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-slate-400 py-8 mt-12 border-t border-slate-800">
      <div className="container mx-auto px-6 text-center">
        <div className="mb-6 max-w-2xl mx-auto">
          <h3 className="text-white font-bold text-lg mb-2">خاتمة</h3>
          <p className="text-sm leading-relaxed">
            إن دمج الذكاء الاصطناعي في التعليم ليس مجرد رفاهية تقنية، بل ضرورة لمواكبة تطورات العصر. فهو يفتح آفاقاً جديدة للإبداع، ويجعل التعلم أكثر متعة وفاعلية، مما يساهم في بناء جيل قادر على قيادة المستقبل الرقمي.
          </p>
        </div>
        
        <div className="flex flex-col items-center justify-center gap-2 pt-6 border-t border-slate-800/50">
            <div className="flex items-center gap-2 text-white font-medium">
                <GraduationCap size={20} />
                <span>مشروع مادة الحاسب وتقنية المعلومات</span>
            </div>
            <p className="text-xs flex items-center gap-1 mt-1">
               تم التصميم بحب <Heart size={10} className="text-red-500 fill-red-500" /> وعناية
            </p>
            <p className="text-xs text-slate-600 mt-2">© {new Date().getFullYear()} جميع الحقوق محفوظة للمشروع المدرسي</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;