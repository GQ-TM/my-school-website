import React from 'react';
import { ExternalLink, Video, Book } from 'lucide-react';
import { ResourceLink } from '../types';

const resources: ResourceLink[] = [
  {
    title: "منصة مدرستي",
    url: "https://schools.madrasati.sa/",
    description: "المنصة الوطنية للتعليم الإلكتروني في المملكة."
  },
  {
    title: "مقدمة في الذكاء الاصطناعي (SDAIA)",
    url: "https://sdaia.gov.sa/",
    description: "الهيئة السعودية للبيانات والذكاء الاصطناعي."
  },
  {
    title: "أكاديمية خان (Khan Academy)",
    url: "https://ar.khanacademy.org/",
    description: "دروس تعليمية مجانية تستخدم تقنيات التكيف."
  }
];

const ExternalResources: React.FC = () => {
  return (
    <section className="container mx-auto px-6 py-12">
       <div className="mb-8 border-r-4 border-blue-500 pr-4">
          <h2 className="text-2xl font-bold text-slate-800">مصادر إثرائية موثوقة</h2>
          <p className="text-slate-500">للاستزادة حول الموضوع</p>
       </div>
       
       <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
         {resources.map((res, idx) => (
           <a 
            key={idx} 
            href={res.url} 
            target="_blank" 
            rel="noopener noreferrer"
            className="group block bg-white p-6 rounded-xl border border-slate-200 shadow-sm hover:shadow-md hover:border-blue-300 transition-all duration-300"
           >
             <div className="flex items-center justify-between mb-3">
               <div className="p-2 bg-blue-50 rounded-lg text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                  {idx === 0 ? <Book size={20} /> : <ExternalLink size={20} />}
               </div>
               <ExternalLink size={16} className="text-slate-300 group-hover:text-blue-400" />
             </div>
             <h3 className="font-bold text-lg text-slate-800 mb-2 group-hover:text-blue-700">{res.title}</h3>
             <p className="text-sm text-slate-500">{res.description}</p>
           </a>
         ))}
       </div>
    </section>
  );
};

export default ExternalResources;