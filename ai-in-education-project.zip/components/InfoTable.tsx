import React from 'react';
import { TableData } from '../types';
import { CheckCircle2, Monitor, LayoutTemplate } from 'lucide-react';

const tableContent: TableData[] = [
  {
    benefit: "التعلم الشخصي (Personalized Learning)",
    usage: "تخصيص المحتوى الدراسي بناءً على نقاط قوة وضعف الطالب.",
    example: "أنظمة التعلم الذكية مثل Knewton التي تعدل المنهج تلقائياً."
  },
  {
    benefit: "توفير وقت المعلم",
    usage: "أتمتة المهام الإدارية وتصحيح الاختبارات الموضوعية.",
    example: "استخدام نماذج Microsoft Forms أو Google للتصحيح التلقائي."
  },
  {
    benefit: "الدعم المتاح 24/7",
    usage: "روبوتات الدردشة (Chatbots) للإجابة على أسئلة الطلاب في أي وقت.",
    example: "بوتات الجامعات للرد على استفسارات القبول والتسجيل."
  },
  {
    benefit: "تعزيز تعلم اللغات",
    usage: "ممارسة المحادثة وتصحيح النطق بشكل فوري.",
    example: "تطبيق Duolingo الذي يستخدم الذكاء الاصطناعي لتخصيص الدروس."
  },
  {
    benefit: "تحليل أداء الطلاب",
    usage: "التنبؤ بمستويات الطلاب وتحديد من يحتاج لدعم إضافي مبكراً.",
    example: "لوحات البيانات (Dashboards) في منصات إدارة التعلم (LMS)."
  }
];

const InfoTable: React.FC = () => {
  return (
    <section className="bg-white py-16">
      <div className="container mx-auto px-6">
        <div className="text-center mb-10">
          <div className="inline-block p-3 rounded-full bg-blue-50 mb-4">
             <LayoutTemplate size={32} className="text-blue-600" />
          </div>
          <h2 className="text-3xl font-bold text-slate-800">تطبيقات وفوائد الذكاء الاصطناعي</h2>
          <p className="text-slate-500 mt-2">نظرة عامة مبسطة</p>
        </div>

        <div className="overflow-x-auto shadow-lg rounded-xl border border-slate-200">
          <table className="w-full text-right bg-white">
            <thead className="bg-blue-600 text-white">
              <tr>
                <th className="p-4 md:p-6 font-bold text-lg w-1/4">الفوائد</th>
                <th className="p-4 md:p-6 font-bold text-lg w-1/3">الاستخدامات</th>
                <th className="p-4 md:p-6 font-bold text-lg w-1/3">أمثلة تطبيقية</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {tableContent.map((row, index) => (
                <tr key={index} className={`hover:bg-blue-50 transition-colors ${index % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'}`}>
                  <td className="p-4 md:p-6 text-slate-800 font-semibold align-top">
                    <div className="flex items-start gap-2">
                      <CheckCircle2 size={18} className="text-green-500 mt-1 flex-shrink-0" />
                      {row.benefit}
                    </div>
                  </td>
                  <td className="p-4 md:p-6 text-slate-600 align-top">
                    {row.usage}
                  </td>
                  <td className="p-4 md:p-6 text-slate-600 align-top">
                    <div className="flex items-start gap-2">
                       <Monitor size={16} className="text-blue-400 mt-1 flex-shrink-0" />
                       {row.example}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};

export default InfoTable;