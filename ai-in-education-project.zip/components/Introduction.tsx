import React from 'react';
import { Lightbulb, BookOpen } from 'lucide-react';

const Introduction: React.FC = () => {
  return (
    <section className="container mx-auto px-6 py-12">
      <div className="flex flex-col md:flex-row items-center gap-10">
        <div className="flex-1 space-y-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-blue-100 rounded-lg text-blue-600">
              <Lightbulb size={24} />
            </div>
            <h2 className="text-3xl font-bold text-slate-800">ما هو الذكاء الاصطناعي في التعليم؟</h2>
          </div>
          <p className="text-lg text-slate-600 leading-relaxed text-justify">
            الذكاء الاصطناعي في التعليم هو استخدام الخوارزميات والبرمجيات الذكية لمحاكاة القدرات البشرية في الفهم والتحليل، بهدف تحسين العملية التعليمية. لا يهدف الذكاء الاصطناعي لاستبدال المعلم، بل ليكون مساعداً ذكياً يوفر بيئة تعليمية مخصصة لكل طالب، ويساعد المعلمين في تقليل الأعباء الروتينية والتركيز على الجانب الإبداعي والتربوي.
          </p>
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 mt-6">
            <h3 className="font-bold text-lg mb-3 flex items-center gap-2 text-slate-700">
              <BookOpen size={20} className="text-blue-500" />
              حقائق سريعة لطلاب المرحلة الثانوية:
            </h3>
            <ul className="space-y-2 list-disc list-inside text-slate-600">
              <li>الذكاء الاصطناعي يمكنه تصحيح الاختبارات فوراً.</li>
              <li>يمكنه اقتراح مصادر تعليمية تناسب مستواك الدراسي.</li>
              <li>يساعد في تعلم اللغات الأجنبية من خلال المحادثة التفاعلية.</li>
            </ul>
          </div>
        </div>
        <div className="flex-1 w-full max-w-md md:max-w-full">
          <div className="relative">
            <div className="absolute -inset-4 bg-blue-200 rounded-2xl opacity-30 transform rotate-3"></div>
            <img 
              src="https://picsum.photos/seed/tech_edu/800/600" 
              alt="الطلاب والتكنولوجيا" 
              className="relative rounded-2xl shadow-lg w-full h-auto object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Introduction;